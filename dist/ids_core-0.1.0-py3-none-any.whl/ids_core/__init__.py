"""
This file initializes the `ids_core` package.
"""